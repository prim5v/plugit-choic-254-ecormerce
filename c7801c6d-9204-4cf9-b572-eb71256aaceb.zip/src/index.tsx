import React from 'react';
import './index.css';
import { render } from 'react-dom';
import { App } from './App';
import axios from 'axios';
// Set default base URL for axios
axios.defaults.baseURL = 'https://biz4293.pythonanywhere.com';
render(<App />, document.getElementById('root'));