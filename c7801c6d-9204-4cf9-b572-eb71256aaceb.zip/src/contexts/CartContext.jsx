import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
const CartContext = createContext();
export function useCart() {
  return useContext(CartContext);
}
export function CartProvider({
  children
}) {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);
  // Get user from localStorage on initial render
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);
  // Load cart from local storage on initial render
  useEffect(() => {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
      setCartItems(JSON.parse(storedCart));
    }
  }, []);
  // Fetch user's cart from API if logged in
  useEffect(() => {
    if (user) {
      fetchUserCart();
    }
  }, [user]);
  // Save cart to local storage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);
  // Fetch user's cart from backend
  const fetchUserCart = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const response = await axios.get(`/api/cart/${user.user_id}`);
      if (response.data && Array.isArray(response.data)) {
        setCartItems(response.data);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching cart:', error);
      setLoading(false);
    }
  };
  // Add item to cart
  const addToCart = async (product, quantity) => {
    // Update local state first for immediate UI feedback
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.product_id === product.product_id);
      if (existingItem) {
        return prevItems.map(item => item.product_id === product.product_id ? {
          ...item,
          quantity: item.quantity + quantity
        } : item);
      } else {
        return [...prevItems, {
          ...product,
          quantity
        }];
      }
    });
    // If user is logged in, update cart on backend
    if (user) {
      try {
        await axios.post('/api/cart/add', {
          user_id: user.user_id,
          product_id: product.product_id,
          quantity: quantity
        });
      } catch (error) {
        console.error('Error adding item to cart on backend:', error);
        // Optionally revert the local state change if the API call fails
      }
    }
  };
  // Update item quantity
  const updateQuantity = async (productId, quantity) => {
    // Find the cart item to get its ID
    const cartItem = cartItems.find(item => item.product_id === productId);
    if (!cartItem) return;
    // Update local state first
    setCartItems(prevItems => prevItems.map(item => item.product_id === productId ? {
      ...item,
      quantity: Math.max(1, quantity)
    } : item));
    // If user is logged in, update cart on backend
    if (user && cartItem.id) {
      try {
        await axios.put(`/api/cart/update/${cartItem.id}`, {
          quantity: Math.max(1, quantity)
        });
      } catch (error) {
        console.error('Error updating cart item quantity on backend:', error);
      }
    }
  };
  // Remove item from cart
  const removeFromCart = async productId => {
    // Find the cart item to get its ID
    const cartItem = cartItems.find(item => item.product_id === productId);
    if (!cartItem) return;
    // Update local state first
    setCartItems(prevItems => prevItems.filter(item => item.product_id !== productId));
    // If user is logged in, update cart on backend
    if (user && cartItem.id) {
      try {
        await axios.delete(`/api/cart/delete/${cartItem.id}`);
      } catch (error) {
        console.error('Error removing item from cart on backend:', error);
      }
    }
  };
  // Clear cart
  const clearCart = async () => {
    setCartItems([]);
    // If user is logged in, clear cart on backend
    if (user) {
      try {
        // We'll remove each item individually as there's no bulk delete endpoint
        const deletePromises = cartItems.map(item => {
          if (item.id) {
            return axios.delete(`/api/cart/delete/${item.id}`);
          }
          return Promise.resolve();
        });
        await Promise.all(deletePromises);
      } catch (error) {
        console.error('Error clearing cart on backend:', error);
      }
    }
  };
  // Sync local cart with backend when user logs in
  const syncCartWithBackend = async () => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) return;
    const userObj = JSON.parse(storedUser);
    setUser(userObj);
    try {
      // Get current cart items from local storage
      const localCartItems = [...cartItems];
      // If there are items in the local cart, add them to the backend
      if (localCartItems.length > 0) {
        const addPromises = localCartItems.map(item => {
          return axios.post('/api/cart/add', {
            user_id: userObj.user_id,
            product_id: item.product_id,
            quantity: item.quantity
          });
        });
        await Promise.all(addPromises);
      }
      // Then fetch the updated cart from backend
      fetchUserCart();
    } catch (error) {
      console.error('Error syncing cart with backend:', error);
    }
  };
  // Calculate total price
  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + item.selling_price * item.quantity, 0);
  };
  const value = {
    cartItems,
    loading,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    calculateTotal,
    syncCartWithBackend
  };
  return <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>;
}