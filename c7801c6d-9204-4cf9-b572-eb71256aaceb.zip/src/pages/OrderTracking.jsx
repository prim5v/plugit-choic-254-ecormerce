import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Search, Package, Loader, AlertCircle, CheckCircle, Clock, Box, Truck, MapPin, ShoppingBag } from 'lucide-react';
const OrderTracking = () => {
  const [orderId, setOrderId] = useState('');
  const [orderData, setOrderData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  // Define the order statuses in sequence
  const orderStatuses = [{
    key: 'Order Placed',
    icon: ShoppingBag
  }, {
    key: 'Processing',
    icon: Clock
  }, {
    key: 'Packed',
    icon: Box
  }, {
    key: 'Shipped',
    icon: Truck
  }, {
    key: 'Out for Delivery',
    icon: MapPin
  }, {
    key: 'Delivered',
    icon: CheckCircle
  }];
  const handleSearch = async e => {
    e.preventDefault();
    if (!orderId.trim()) {
      setError('Please enter an order ID');
      return;
    }
    setLoading(true);
    setError('');
    setOrderData(null);
    try {
      const response = await axios.get(`https://biz4293.pythonanywhere.com/api/track_order?order_id=${orderId}`);
      if (response.data.success) {
        setOrderData(response.data.order);
      } else {
        setError(response.data.message || 'Order not found');
      }
    } catch (err) {
      console.error('Error tracking order:', err);
      setError('Failed to track order. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  // Get current status index
  const getCurrentStatusIndex = () => {
    if (!orderData || !orderData.order_status) return -1;
    return orderStatuses.findIndex(status => status.key === orderData.order_status);
  };
  const currentStatusIndex = getCurrentStatusIndex();
  return <div className="min-h-screen bg-[#f8f5f1] py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-[#5a3921]">Track Your Order</h1>
          <p className="mt-2 text-gray-600">
            Enter your order ID to track the current status of your order
          </p>
        </div>
        {/* Search Form */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
            <div className="flex-grow relative">
              <input type="text" value={orderId} onChange={e => setOrderId(e.target.value)} placeholder="Enter your order ID (e.g. ORD-1234)" className="w-full px-4 py-3 pl-10 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#8c5e3b] focus:border-[#8c5e3b] outline-none" />
              <Package size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            <button type="submit" disabled={loading} className="bg-[#8c5e3b] hover:bg-[#5a3921] text-white px-6 py-3 rounded-md font-medium flex items-center justify-center disabled:opacity-70">
              {loading ? <Loader size={18} className="animate-spin mr-2" /> : <Search size={18} className="mr-2" />}
              Track Order
            </button>
          </form>
          {error && <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-md flex items-center">
              <AlertCircle size={18} className="mr-2" />
              <span>{error}</span>
            </div>}
        </div>
        {/* Order Status */}
        {orderData && <div className="bg-white rounded-lg shadow-md p-6">
            {/* Order Details */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-[#5a3921] mb-4">
                Order #{orderData.order_id}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Order Date</p>
                  <p className="font-medium">
                    {new Date(orderData.order_date).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Estimated Delivery</p>
                  <p className="font-medium">
                    {orderData.estimated_delivery ? new Date(orderData.estimated_delivery).toLocaleDateString() : 'To be determined'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Shipping Address</p>
                  <p className="font-medium">{orderData.shipping_address || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total Amount</p>
                  <p className="font-medium">${orderData.total_amount?.toFixed(2) || 'N/A'}</p>
                </div>
              </div>
            </div>
            {/* Status Stepper */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-[#5a3921] mb-4">
                Tracking Status
              </h3>
              <div className="relative">
                {/* Progress Line */}
                <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200 transform -translate-x-1/2"></div>
                {/* Status Steps */}
                <div className="space-y-8">
                  {orderStatuses.map((status, index) => {
                // Determine step status
                const isCompleted = index <= currentStatusIndex;
                const isCurrent = index === currentStatusIndex;
                const isPending = index > currentStatusIndex;
                return <div key={status.key} className="flex items-start">
                        <div className="relative flex items-center justify-center">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center z-10 ${isCompleted ? 'bg-green-100 text-green-600' : isCurrent ? 'bg-blue-100 text-blue-600 ring-2 ring-blue-300' : 'bg-gray-100 text-gray-400'}`}>
                            <status.icon size={20} />
                          </div>
                        </div>
                        <div className="ml-4 flex-1">
                          <h4 className={`font-medium ${isCompleted ? 'text-green-700' : isCurrent ? 'text-blue-700' : 'text-gray-500'}`}>
                            {status.key}
                          </h4>
                          {isCurrent && orderData.status_update_time && <p className="text-sm text-gray-500">
                              Updated: {new Date(orderData.status_update_time).toLocaleString()}
                            </p>}
                          {isCompleted && !isCurrent && <p className="text-sm text-gray-500">Completed</p>}
                          {isPending && <p className="text-sm text-gray-400">Pending</p>}
                        </div>
                      </div>;
              })}
                </div>
              </div>
            </div>
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button onClick={() => navigate('/account/orders')} className="bg-[#8c5e3b] hover:bg-[#5a3921] text-white px-6 py-3 rounded-md font-medium">
                View All Orders
              </button>
              <button onClick={() => navigate('/')} className="border border-[#8c5e3b] text-[#8c5e3b] hover:bg-[#f8f5f1] px-6 py-3 rounded-md font-medium">
                Continue Shopping
              </button>
            </div>
          </div>}
      </div>
    </div>;
};
export default OrderTracking;