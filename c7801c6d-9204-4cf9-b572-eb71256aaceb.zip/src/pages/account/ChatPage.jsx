import React, { useEffect, useState, useRef } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Send, Phone, Video, MoreVertical, Search, AlertCircle, MessageSquare } from 'lucide-react';
const ChatPage = () => {
  const {
    user
  } = useAuth();
  const [selectedSeller, setSelectedSeller] = useState(null);
  const [message, setMessage] = useState('');
  const [chats, setChats] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);
  useEffect(() => {
    // Simulate fetching chats from an API
    const fetchChats = async () => {
      setLoading(true);
      try {
        // This would be replaced with an actual API call
        setTimeout(() => {
          const mockChats = [{
            id: 1,
            name: 'Electronics Store',
            avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
            lastMessage: 'Your order has been shipped!',
            time: '10:30 AM',
            unread: 2
          }, {
            id: 2,
            name: 'Gadget World',
            avatar: 'https://randomuser.me/api/portraits/women/2.jpg',
            lastMessage: 'Do you have any questions about the product?',
            time: 'Yesterday',
            unread: 0
          }, {
            id: 3,
            name: 'Tech Solutions',
            avatar: 'https://randomuser.me/api/portraits/men/3.jpg',
            lastMessage: 'Thank you for your purchase!',
            time: 'Oct 12',
            unread: 0
          }];
          setChats(mockChats);
          setLoading(false);
        }, 1000);
      } catch (err) {
        console.error('Error fetching chats:', err);
        setError('Failed to load chats. Please try again later.');
        setLoading(false);
      }
    };
    fetchChats();
  }, [user]);
  useEffect(() => {
    // Scroll to bottom whenever messages change
    messagesEndRef.current?.scrollIntoView({
      behavior: 'smooth'
    });
  }, [messages]);
  const selectSeller = seller => {
    setSelectedSeller(seller);
    // Simulate fetching messages for this seller
    const mockMessages = [{
      id: 1,
      sender: 'seller',
      text: 'Hello! How can I help you today?',
      time: '10:00 AM'
    }, {
      id: 2,
      sender: 'user',
      text: 'Hi, I wanted to ask about the wireless earbuds I purchased last week.',
      time: '10:05 AM'
    }, {
      id: 3,
      sender: 'seller',
      text: 'Of course! What would you like to know about them?',
      time: '10:07 AM'
    }, {
      id: 4,
      sender: 'user',
      text: "The battery doesn't seem to last as long as advertised. Is this normal?",
      time: '10:10 AM'
    }, {
      id: 5,
      sender: 'seller',
      text: "I'm sorry to hear that. The battery should last about 5-6 hours on a full charge. Have you fully charged them before use?",
      time: '10:15 AM'
    }];
    setMessages(mockMessages);
  };
  const sendMessage = e => {
    e.preventDefault();
    if (!message.trim() || !selectedSeller) return;
    const newMessage = {
      id: messages.length + 1,
      sender: 'user',
      text: message,
      time: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    setMessages([...messages, newMessage]);
    setMessage('');
    // Simulate seller response after a delay
    setTimeout(() => {
      const sellerResponse = {
        id: messages.length + 2,
        sender: 'seller',
        text: "Thanks for your message! I'll get back to you shortly.",
        time: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit'
        })
      };
      setMessages(prev => [...prev, sellerResponse]);
    }, 1000);
  };
  if (loading && chats.length === 0) {
    return <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#8c5e3b]"></div>
      </div>;
  }
  if (error) {
    return <div className="p-4 bg-red-50 rounded-md text-red-700 flex items-center">
        <AlertCircle size={20} className="mr-2" />
        <span>{error}</span>
      </div>;
  }
  return <div>
      <h2 className="text-2xl font-bold text-[#5a3921] mb-6">
        Chat with Sellers
      </h2>
      <div className="bg-white rounded-lg overflow-hidden border border-gray-200 h-[600px] flex">
        {/* Chat list */}
        <div className="w-full md:w-1/3 border-r border-gray-200 overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <div className="relative">
              <input type="text" placeholder="Search chats..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#8c5e3b] focus:border-[#8c5e3b]" />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
          </div>
          <div>
            {chats.map(chat => <div key={chat.id} className={`flex items-center p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${selectedSeller?.id === chat.id ? 'bg-gray-100' : ''}`} onClick={() => selectSeller(chat)}>
                <div className="relative">
                  <img src={chat.avatar} alt={chat.name} className="w-12 h-12 rounded-full object-cover" />
                  {chat.unread > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {chat.unread}
                    </span>}
                </div>
                <div className="ml-4 flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <h3 className="text-sm font-medium text-gray-900 truncate">
                      {chat.name}
                    </h3>
                    <span className="text-xs text-gray-500">{chat.time}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">
                    {chat.lastMessage}
                  </p>
                </div>
              </div>)}
          </div>
        </div>
        {/* Chat messages */}
        <div className="hidden md:flex flex-col w-2/3">
          {selectedSeller ? <>
              {/* Chat header */}
              <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                <div className="flex items-center">
                  <img src={selectedSeller.avatar} alt={selectedSeller.name} className="w-10 h-10 rounded-full object-cover" />
                  <div className="ml-3">
                    <h3 className="font-medium text-gray-900">
                      {selectedSeller.name}
                    </h3>
                    <p className="text-xs text-green-500">Online</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <button className="text-gray-500 hover:text-gray-700">
                    <Phone size={18} />
                  </button>
                  <button className="text-gray-500 hover:text-gray-700">
                    <Video size={18} />
                  </button>
                  <button className="text-gray-500 hover:text-gray-700">
                    <MoreVertical size={18} />
                  </button>
                </div>
              </div>
              {/* Messages */}
              <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
                <div className="space-y-4">
                  {messages.map(msg => <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-xs md:max-w-md rounded-lg p-3 ${msg.sender === 'user' ? 'bg-[#8c5e3b] text-white rounded-br-none' : 'bg-white border border-gray-200 rounded-bl-none'}`}>
                        <p className="text-sm">{msg.text}</p>
                        <p className={`text-xs mt-1 text-right ${msg.sender === 'user' ? 'text-gray-200' : 'text-gray-500'}`}>
                          {msg.time}
                        </p>
                      </div>
                    </div>)}
                  <div ref={messagesEndRef} />
                </div>
              </div>
              {/* Message input */}
              <div className="p-4 border-t border-gray-200">
                <form onSubmit={sendMessage} className="flex items-center">
                  <input type="text" value={message} onChange={e => setMessage(e.target.value)} placeholder="Type a message..." className="flex-1 border border-gray-300 rounded-l-md py-2 px-4 focus:outline-none focus:ring-1 focus:ring-[#8c5e3b] focus:border-[#8c5e3b]" />
                  <button type="submit" className="bg-[#8c5e3b] text-white p-2 rounded-r-md hover:bg-[#5a3921]">
                    <Send size={18} />
                  </button>
                </form>
              </div>
            </> : <div className="flex-1 flex flex-col items-center justify-center p-4">
              <div className="bg-gray-100 rounded-full p-6 mb-4">
                <MessageSquare size={48} className="text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-700 mb-2">
                Select a chat
              </h3>
              <p className="text-gray-500 text-center">
                Choose a seller from the list to start chatting
              </p>
            </div>}
        </div>
        {/* Mobile: No chat selected message */}
        <div className="flex flex-col items-center justify-center p-4 w-full md:hidden">
          <div className="bg-gray-100 rounded-full p-6 mb-4">
            <MessageSquare size={48} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-700 mb-2">
            Your Conversations
          </h3>
          <p className="text-gray-500 text-center">
            Select a chat from above to view your messages
          </p>
        </div>
      </div>
    </div>;
};
export default ChatPage;