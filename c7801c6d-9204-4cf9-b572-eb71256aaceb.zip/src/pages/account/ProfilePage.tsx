import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { User, Mail, AlertCircle, Check } from 'lucide-react';
const ProfilePage = () => {
  const {
    user
  } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(false);
    try {
      // This would be an actual API call to update the user profile
      // For now, we'll just simulate a successful update
      setTimeout(() => {
        setLoading(false);
        setSuccess(true);
        // Hide success message after 3 seconds
        setTimeout(() => {
          setSuccess(false);
        }, 3000);
      }, 1000);
    } catch (err) {
      setError('Failed to update profile. Please try again.');
      setLoading(false);
    }
  };
  return <div>
      <h2 className="text-2xl font-bold text-[#5a3921] mb-6">My Profile</h2>
      {error && <div className="mb-6 p-4 bg-red-50 rounded-md text-red-700 flex items-center">
          <AlertCircle size={18} className="mr-2" />
          <span>{error}</span>
        </div>}
      {success && <div className="mb-6 p-4 bg-green-50 rounded-md text-green-700 flex items-center">
          <Check size={18} className="mr-2" />
          <span>Profile updated successfully!</span>
        </div>}
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-6">
          {/* Profile Picture */}
          <div className="flex flex-col items-center sm:items-start">
            <div className="bg-gray-100 rounded-full h-24 w-24 flex items-center justify-center mb-4">
              {user?.name ? <span className="text-2xl font-bold text-[#8c5e3b]">
                  {user.name.charAt(0).toUpperCase()}
                </span> : <User size={40} className="text-gray-400" />}
            </div>
            <button type="button" className="text-[#8c5e3b] hover:text-[#5a3921] text-sm font-medium">
              Change Profile Picture
            </button>
          </div>
          {/* Name */}
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User size={18} className="text-gray-400" />
              </div>
              <input id="name" name="name" type="text" value={name} onChange={e => setName(e.target.value)} className="appearance-none block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#8c5e3b] focus:border-[#8c5e3b]" />
            </div>
          </div>
          {/* Email */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail size={18} className="text-gray-400" />
              </div>
              <input id="email" name="email" type="email" value={email} onChange={e => setEmail(e.target.value)} className="appearance-none block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#8c5e3b] focus:border-[#8c5e3b]" />
            </div>
          </div>
          {/* Phone Number */}
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
              Phone Number
            </label>
            <input id="phone" name="phone" type="tel" placeholder="e.g. 0712345678" className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#8c5e3b] focus:border-[#8c5e3b]" />
          </div>
          {/* Address */}
          <div>
            <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
              Delivery Address
            </label>
            <textarea id="address" name="address" rows={3} placeholder="Enter your delivery address" className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#8c5e3b] focus:border-[#8c5e3b]"></textarea>
          </div>
          <div className="pt-4">
            <button type="submit" disabled={loading} className="w-full sm:w-auto bg-[#8c5e3b] hover:bg-[#5a3921] text-white py-2 px-6 rounded-md font-medium flex items-center justify-center disabled:opacity-50">
              {loading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </div>
      </form>
    </div>;
};
export default ProfilePage;