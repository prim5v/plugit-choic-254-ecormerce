import React, { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Package, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
const OrdersPage = () => {
  const {
    user
  } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedOrder, setExpandedOrder] = useState(null);
  useEffect(() => {
    // Simulate fetching orders from an API
    const fetchOrders = async () => {
      setLoading(true);
      try {
        // This would be replaced with an actual API call
        setTimeout(() => {
          const mockOrders = [{
            id: 'ORD-1234',
            date: '2023-10-15',
            status: 'Delivered',
            total: 299.99,
            items: [{
              product_id: 'PROD-001',
              name: 'Wireless Earbuds',
              price: 129.99,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
            }, {
              product_id: 'PROD-002',
              name: 'Smart Watch',
              price: 169.99,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
            }]
          }, {
            id: 'ORD-1235',
            date: '2023-10-10',
            status: 'Processing',
            total: 459.99,
            items: [{
              product_id: 'PROD-003',
              name: 'Bluetooth Speaker',
              price: 89.99,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
            }, {
              product_id: 'PROD-004',
              name: 'Noise Cancelling Headphones',
              price: 349.99,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
            }]
          }];
          setOrders(mockOrders);
          setLoading(false);
        }, 1000);
      } catch (err) {
        console.error('Error fetching orders:', err);
        setError('Failed to load orders. Please try again later.');
        setLoading(false);
      }
    };
    fetchOrders();
  }, [user]);
  const toggleOrderDetails = orderId => {
    if (expandedOrder === orderId) {
      setExpandedOrder(null);
    } else {
      setExpandedOrder(orderId);
    }
  };
  if (loading) {
    return <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#8c5e3b]"></div>
      </div>;
  }
  if (error) {
    return <div className="p-4 bg-red-50 rounded-md text-red-700 flex items-center">
        <AlertCircle size={20} className="mr-2" />
        <span>{error}</span>
      </div>;
  }
  if (orders.length === 0) {
    return <div className="text-center py-12">
        <Package size={48} className="mx-auto text-gray-400 mb-4" />
        <h3 className="text-xl font-medium text-[#5a3921] mb-2">
          No Orders Yet
        </h3>
        <p className="text-gray-600">You haven't placed any orders yet.</p>
      </div>;
  }
  return <div>
      <h2 className="text-2xl font-bold text-[#5a3921] mb-6">My Orders</h2>
      <div className="space-y-4">
        {orders.map(order => <div key={order.id} className="border border-gray-200 rounded-lg overflow-hidden">
            {/* Order header */}
            <div className="bg-gray-50 px-4 py-3 flex flex-col sm:flex-row justify-between items-start sm:items-center cursor-pointer" onClick={() => toggleOrderDetails(order.id)}>
              <div>
                <div className="flex items-center">
                  <h3 className="text-lg font-medium text-[#5a3921]">
                    Order #{order.id}
                  </h3>
                  <span className={`ml-3 px-2 py-1 text-xs rounded-full ${order.status === 'Delivered' ? 'bg-green-100 text-green-800' : order.status === 'Processing' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    {order.status}
                  </span>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Placed on {new Date(order.date).toLocaleDateString()}
                </p>
              </div>
              <div className="flex items-center mt-2 sm:mt-0">
                <span className="font-medium text-[#8c5e3b] mr-3">
                  ${order.total.toFixed(2)}
                </span>
                {expandedOrder === order.id ? <ChevronUp size={20} className="text-gray-500" /> : <ChevronDown size={20} className="text-gray-500" />}
              </div>
            </div>
            {/* Order details */}
            {expandedOrder === order.id && <div className="px-4 py-3 border-t border-gray-200">
                <h4 className="font-medium text-gray-700 mb-3">Order Items</h4>
                <div className="space-y-4">
                  {order.items.map(item => <div key={item.product_id} className="flex items-center">
                      <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                        <img src={item.image} alt={item.name} className="h-full w-full object-cover object-center" />
                      </div>
                      <div className="ml-4 flex-1">
                        <h5 className="text-sm font-medium text-[#5a3921]">
                          {item.name}
                        </h5>
                        <p className="text-sm text-gray-500 mt-1">
                          Qty: {item.quantity} × ${item.price.toFixed(2)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-[#8c5e3b]">
                          ${(item.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    </div>)}
                </div>
                <div className="border-t border-gray-200 mt-4 pt-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span>${(order.total * 0.84).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-gray-600">Tax</span>
                    <span>${(order.total * 0.16).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-gray-600">Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between font-medium mt-2 pt-2 border-t border-gray-200">
                    <span>Total</span>
                    <span className="text-[#8c5e3b]">
                      ${order.total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>}
          </div>)}
      </div>
    </div>;
};
export default OrdersPage;