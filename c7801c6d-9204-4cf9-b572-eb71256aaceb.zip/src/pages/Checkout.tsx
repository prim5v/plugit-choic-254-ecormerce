import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { CreditCard, Phone, Check, AlertCircle } from 'lucide-react';
const Checkout = () => {
  const {
    cartItems,
    calculateTotal,
    clearCart
  } = useCart();
  const {
    user,
    isAuthenticated
  } = useAuth();
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const subtotal = calculateTotal();
  const tax = subtotal * 0.16;
  const total = subtotal + tax;
  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <div className="min-h-screen bg-[#f8f5f1] py-12">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <AlertCircle size={48} className="text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[#5a3921] mb-4">
              Authentication Required
            </h2>
            <p className="text-gray-600 mb-6">
              Please login to your account to proceed with checkout.
            </p>
            <button onClick={() => navigate('/login')} className="bg-[#8c5e3b] hover:bg-[#5a3921] text-white px-6 py-3 rounded-md font-medium">
              Go to Login
            </button>
          </div>
        </div>
      </div>;
  }
  // Redirect to cart if cart is empty
  if (cartItems.length === 0) {
    return <div className="min-h-screen bg-[#f8f5f1] py-12">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <AlertCircle size={48} className="text-yellow-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[#5a3921] mb-4">
              Your Cart is Empty
            </h2>
            <p className="text-gray-600 mb-6">
              Add some products to your cart before proceeding to checkout.
            </p>
            <button onClick={() => navigate('/')} className="bg-[#8c5e3b] hover:bg-[#5a3921] text-white px-6 py-3 rounded-md font-medium">
              Browse Products
            </button>
          </div>
        </div>
      </div>;
  }
  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setLoading(true);
    // Validate phone number (simple validation for Kenya numbers)
    if (!phoneNumber.match(/^(?:254|\+254|0)?(7[0-9]{8})$/)) {
      setError('Please enter a valid phone number');
      setLoading(false);
      return;
    }
    try {
      // Format the phone number for M-Pesa (ensure it starts with 254)
      let formattedPhone = phoneNumber;
      if (phoneNumber.startsWith('0')) {
        formattedPhone = '254' + phoneNumber.substring(1);
      } else if (!phoneNumber.startsWith('254') && !phoneNumber.startsWith('+254')) {
        formattedPhone = '254' + phoneNumber;
      }
      // Remove + sign if present
      formattedPhone = formattedPhone.replace('+', '');
      // Make payment request
      const response = await axios.post('https://biz4293.pythonanywhere.com/api/mpesa_payment', {
        phone_number: formattedPhone,
        user_id: user.user_id,
        amount: total.toFixed(2)
      });
      if (response.data.success) {
        setSuccess(true);
        // Clear cart after successful payment
        setTimeout(() => {
          clearCart();
          navigate('/account/orders');
        }, 5000);
      } else {
        setError(response.data.message || 'Payment failed. Please try again.');
      }
    } catch (err) {
      console.error('Payment error:', err);
      setError(err.response?.data?.message || 'Payment processing failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  if (success) {
    return <div className="min-h-screen bg-[#f8f5f1] py-12">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check size={32} className="text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-[#5a3921] mb-4">
              Payment Initiated!
            </h2>
            <p className="text-gray-600 mb-6">
              A payment request has been sent to your phone. Please complete the
              M-Pesa payment process.
            </p>
            <p className="text-sm text-gray-500 mb-8">
              You will be redirected to your orders page shortly.
            </p>
            <button onClick={() => navigate('/account/orders')} className="bg-[#8c5e3b] hover:bg-[#5a3921] text-white px-6 py-3 rounded-md font-medium">
              Go to Orders
            </button>
          </div>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-[#f8f5f1] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-[#5a3921] mb-8">Checkout</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Payment Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h2 className="text-xl font-bold text-[#5a3921] mb-6">
                  Payment Details
                </h2>
                {error && <div className="mb-6 p-4 bg-red-100 border border-red-200 text-red-700 rounded-md flex items-center">
                    <AlertCircle size={18} className="mr-2" />
                    <span>{error}</span>
                  </div>}
                <form onSubmit={handleSubmit}>
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-medium text-[#5a3921]">
                        M-Pesa Payment
                      </h3>
                      <div className="flex items-center">
                        <CreditCard size={20} className="text-[#8c5e3b] mr-2" />
                        <span className="text-sm text-gray-600">
                          Secure Payment
                        </span>
                      </div>
                    </div>
                    <p className="text-gray-600 mb-6">
                      Enter your phone number below to receive an M-Pesa payment
                      prompt.
                    </p>
                    <div className="mb-6">
                      <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Phone size={18} className="text-gray-400" />
                        </div>
                        <input id="phoneNumber" name="phoneNumber" type="tel" required value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} placeholder="e.g. 0712345678" className="appearance-none block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#8c5e3b] focus:border-[#8c5e3b]" />
                      </div>
                      <p className="mt-1 text-xs text-gray-500">
                        Enter your phone number in the format 0712345678 or
                        254712345678
                      </p>
                    </div>
                  </div>
                  <div className="border-t border-gray-200 pt-6">
                    <button type="submit" disabled={loading} className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-md font-medium flex items-center justify-center disabled:opacity-50">
                      {loading ? 'Processing...' : 'Pay with M-Pesa'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
              <h2 className="text-lg font-bold text-[#5a3921] mb-6">
                Order Summary
              </h2>
              <div className="mb-6">
                {cartItems.map(item => <div key={item.product_id} className="flex justify-between py-2">
                    <div className="flex">
                      <span className="text-gray-600">
                        {item.name} × {item.quantity}
                      </span>
                    </div>
                    <span className="font-medium">
                      ${(item.selling_price * item.quantity).toFixed(2)}
                    </span>
                  </div>)}
              </div>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax (16%)</span>
                  <span className="font-medium">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium">Free</span>
                </div>
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <div className="flex justify-between">
                    <span className="text-lg font-bold text-[#5a3921]">
                      Total
                    </span>
                    <span className="text-lg font-bold text-[#8c5e3b]">
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>;
};
export default Checkout;